import React from "react";

const Home = ({ user }) => {
  return (
    <div>
      <h2>Welcome, {user.name}!</h2>
      <button>Log Out</button>
    </div>
  );
};

export default Home;
